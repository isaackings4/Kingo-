/* Kingo : adaptateur Supabase (base, fichiers, comptes). Actif seulement si config.js est rempli. */
(function(){
  var C=window.KINGO||{};
  if(!C.SUPABASE_URL||!C.SUPABASE_KEY||typeof supabase==="undefined")return;
  var sb=supabase.createClient(C.SUPABASE_URL,C.SUPABASE_KEY);
  window.KINGO_BLOB=C.SUPABASE_URL+"/storage/v1/object/public/videos/a/";
  var sess=null,adm=false;
  function whenDom(f){if(document.readyState!=="loading")f();else document.addEventListener("DOMContentLoaded",f)}
  function hex32(){var a=new Uint8Array(16);crypto.getRandomValues(a);return Array.prototype.map.call(a,function(b){return("0"+b.toString(16)).slice(-2)}).join("")}
  function err(code,e){return {code:code,message:String(e&&e.message||e)}}
  function idOf(p){return p.slice(p.lastIndexOf("/")+1)}
  function parentOf(p){return p.slice(0,p.lastIndexOf("/"))}
  function snap(r){return {id:r.id,exists:true,data:function(){return r.data},metadata:{}}}
  function docRef(p){
    var o={id:idOf(p),path:p,
      get:async function(){var r=await sb.from("docs").select("id,data").eq("path",p).maybeSingle();if(r.error)throw err("unavailable",r.error);return r.data?snap(r.data):{id:idOf(p),exists:false,data:function(){return undefined},metadata:{}}},
      set:async function(d){var r=await sb.from("docs").upsert({path:p,parent:parentOf(p),id:idOf(p),data:d,updated_at:new Date().toISOString()});if(r.error)throw err("permission_denied",r.error)},
      update:async function(d){var g=await o.get();if(!g.exists)throw err("invalid_argument","absent");await o.set(Object.assign({},g.data(),d))},
      delete:async function(){var r=await sb.from("docs").delete().eq("path",p);if(r.error)throw err("permission_denied",r.error)},
      collection:function(sub){return colRef(p+"/"+sub)}};
    return o}
  function colRef(path,st){st=st||{};
    var o={path:path,
      doc:function(id){return docRef(path+"/"+id)},
      where:function(){return o},
      orderBy:function(f,d){return colRef(path,Object.assign({},st,{o:[f,d||"asc"]}))},
      limit:function(n){return colRef(path,Object.assign({},st,{l:n}))},
      get:async function(){var q=sb.from("docs").select("id,data").eq("parent",path);if(st.o)q=q.order("data->>"+st.o[0],{ascending:st.o[1]!=="desc"});if(st.l)q=q.limit(st.l);var r=await q;if(r.error)throw err("unavailable",r.error);var d=(r.data||[]).map(snap);return {docs:d,size:d.length,empty:!d.length}},
      onSnapshot:function(next,onErr){var dead=false,t=null;
        function run(){o.get().then(function(s){if(!dead)next(s)}).catch(function(e){if(!dead&&onErr)onErr(e)})}
        run();
        var ch=sb.channel("c_"+hex32()).on("postgres_changes",{event:"*",schema:"public",table:"docs",filter:"parent=eq."+path},function(){clearTimeout(t);t=setTimeout(run,150)}).subscribe();
        return function(){dead=true;sb.removeChannel(ch)}}};
    return o}
  var DB={doc:docRef,collection:function(p){return colRef(p)}};
  var AS={
    upload:async function(blob,opt){var id=hex32(),type=(opt&&opt.type)||blob.type||"application/octet-stream";var r=await sb.storage.from("videos").upload("a/"+id,blob,{contentType:type,upsert:false});if(r.error)throw err("not_granted",r.error);return {id:id,url:window.KINGO_BLOB+id,sizeBytes:blob.size,contentType:type}},
    delete:async function(id){await sb.storage.from("videos").remove(["a/"+id]);return {deleted:true}}};
  var US={id:async function(){return sess?sess.user.id:null},canEdit:async function(){return adm},isOwner:async function(){return false},profiles:async function(){return {}}};
  function b64(blob){return new Promise(function(res){var f=new FileReader();f.onload=function(){res(String(f.result).split(",")[1])};f.readAsDataURL(blob)})}
  var SAMPLE=function(){throw err("unavailable","non supporté")};
  SAMPLE.limits=async function(){return {images:{maxCount:4}}};
  SAMPLE.json=async function(prompt,opts){
    var imgs=await Promise.all((opts.images||[]).map(b64));
    var tok=(await sb.auth.getSession()).data.session.access_token;
    var r=await fetch(C.MODERATE_URL,{method:"POST",headers:{"Content-Type":"application/json",Authorization:"Bearer "+tok,apikey:C.SUPABASE_KEY},body:JSON.stringify({images:imgs})});
    if(!r.ok)throw err("unavailable","moderation");return await r.json()};
  var ready=(async function(){
    try{var r=await sb.auth.getSession();sess=r.data.session}catch(e){}
    if(sess){try{var q=await sb.from("admins").select("uid").eq("uid",sess.user.id);adm=!!(q.data&&q.data.length)}catch(e){}}
    whenDom(wire)})();
  function wire(){
    var au=document.getElementById("au"),m=document.getElementById("auM");
    if(!sess&&au)au.style.display="flex";
    if(sess){var so=document.getElementById("soR");if(so){so.style.display="";document.getElementById("so").onclick=async function(){await sb.auth.signOut();location.reload()}}}
    function creds(){return {email:document.getElementById("auE").value.trim(),password:document.getElementById("auP").value}}
    var bi=document.getElementById("auIn"),bu=document.getElementById("auUp");
    if(bi)bi.onclick=async function(){var c=creds();m.textContent="Connexion…";var r=await sb.auth.signInWithPassword(c);if(r.error){m.textContent="Échec : "+r.error.message;return}location.reload()};
    if(bu)bu.onclick=async function(){var c=creds();if(c.password.length<8){m.textContent="Mot de passe : 8 caractères minimum.";return}m.textContent="Création du compte…";var r=await sb.auth.signUp(c);if(r.error){m.textContent="Échec : "+r.error.message;return}if(r.data&&r.data.session)location.reload();else m.textContent="Compte créé. Vérifie ta boîte mail pour confirmer, puis connecte-toi."};
  }
  window.claude={use:async function(n){await ready;
    if(!sess)return null;
    if(n==="db")return DB;
    if(n==="assets")return AS;
    if(n==="user")return US;
    if(n==="sample")return C.MODERATE_URL?SAMPLE:null;
    return null}};
})();
