/* Remplis ces 3 valeurs (voir LISEZ-MOI.txt). Laisse vide pour le mode local. */
window.KINGO={
  SUPABASE_URL:"",      // ex : https://abcdxyz.supabase.co
  SUPABASE_KEY:"",      // clé "anon public" du projet (pas la clé service_role)
  MODERATE_URL:""       // optionnel : https://abcdxyz.supabase.co/functions/v1/moderate
};
