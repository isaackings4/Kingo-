-- KINGO : à coller dans Supabase > SQL Editor > Run (une seule fois)

create table if not exists public.docs(
  path text primary key,
  parent text not null,
  id text not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  constraint path_ok check (path = parent || '/' || id),
  constraint size_ok check (pg_column_size(data) <= 262144)
);
create index if not exists docs_parent_idx on public.docs(parent);
alter table public.docs replica identity full;

create table if not exists public.admins(uid uuid primary key);

alter table public.docs enable row level security;
alter table public.admins enable row level security;

create or replace function public.is_admin() returns boolean
language sql security definer set search_path = public stable as
$$ select exists(select 1 from public.admins where uid = auth.uid()) $$;

create or replace function public.strikes(u text) returns int
language sql security definer set search_path = public stable as
$$ select coalesce(sum((data->'m'->>u)::int),0)::int from public.docs where parent = 'strikes' $$;

create or replace function public.can_write(par text, i text) returns boolean
language sql stable as $$
  select auth.uid() is not null and (
    (par = 'profiles' and (i = auth.uid()::text or public.is_admin()))
    or (par in ('likes','views','follows') and (i = auth.uid()::text or public.is_admin()))
    or (par in ('posts','shares','comments','reports')
        and (i = auth.uid()::text or public.is_admin())
        and (public.is_admin() or public.strikes(auth.uid()::text) < 3))
    or (par in ('approved','strikes','config') and public.is_admin())
    or (par = 'data/users/' || auth.uid()::text)
  )
$$;

drop policy if exists admins_self on public.admins;
create policy admins_self on public.admins for select using (uid = auth.uid());

drop policy if exists docs_read on public.docs;
create policy docs_read on public.docs for select
  using (parent not like 'data/users/%' or parent = 'data/users/' || auth.uid()::text);

drop policy if exists docs_write on public.docs;
create policy docs_write on public.docs for all
  using (public.can_write(parent, id))
  with check (public.can_write(parent, id));

-- Temps réel
alter publication supabase_realtime add table public.docs;

-- Stockage des vidéos (50 Mo max par fichier)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('videos','videos',true,52428800,array['video/mp4','video/webm','video/quicktime','image/jpeg'])
on conflict (id) do update set public = true, file_size_limit = 52428800;

drop policy if exists videos_read on storage.objects;
create policy videos_read on storage.objects for select using (bucket_id = 'videos');
drop policy if exists videos_insert on storage.objects;
create policy videos_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'videos' and name like 'a/%');
drop policy if exists videos_delete on storage.objects;
create policy videos_delete on storage.objects for delete to authenticated
  using (bucket_id = 'videos' and (owner = auth.uid() or public.is_admin()));

-- APRÈS ta première inscription dans l'appli, rends-toi administrateur
-- (Authentication > Users > copie ton "User UID") :
-- insert into public.admins(uid) values ('COLLE-TON-UID-ICI');
