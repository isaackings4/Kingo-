// Contrôle automatique des images d'une vidéo avant publication (optionnel).
// Déploiement : supabase functions deploy moderate ; supabase secrets set ANTHROPIC_API_KEY=...
const KEY = Deno.env.get("ANTHROPIC_API_KEY");
const PROMPT = "Tu es un filtre de sécurité pour une application de partage de vidéos. Ces images viennent d'une même vidéo. Réponds uniquement en JSON : {\"ok\":true,\"why\":\"\"} ou {\"ok\":false,\"why\":\"raison courte\"}. Mets ok=false seulement si tu vois clairement : de la pornographie ou de la nudité explicite, de la violence graphique ou du gore, du contenu qui sexualise ou expose des mineurs, ou des armes utilisées pour menacer. Sinon ok=true. En cas de doute léger, ok=true.";
const cors = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type" };
const json = (o: unknown) => new Response(JSON.stringify(o), { headers: { ...cors, "content-type": "application/json" } });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  try {
    const { images } = await req.json();
    if (!Array.isArray(images) || images.length < 1 || images.length > 6) return json({ ok: true });
    const content = [
      ...images.map((d: string) => ({ type: "image", source: { type: "base64", media_type: "image/jpeg", data: d } })),
      { type: "text", text: PROMPT },
    ];
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "x-api-key": KEY!, "anthropic-version": "2023-06-01", "content-type": "application/json" },
      body: JSON.stringify({ model: "claude-haiku-5-5", max_tokens: 100, messages: [{ role: "user", content }] }),
    });
    const j = await r.json();
    const t = j?.content?.[0]?.text ?? "{}";
    const m = t.match(/\{[\s\S]*\}/);
    const out = m ? JSON.parse(m[0]) : { ok: true };
    return json({ ok: out.ok !== false, why: out.why ?? "" });
  } catch (_) {
    return json({ ok: true });
  }
});
